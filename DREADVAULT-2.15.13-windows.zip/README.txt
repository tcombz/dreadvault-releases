DREADVAULT - The Vault Gauntlet   v1.7.6 (beta)
=========================================
Windows: EXTRACT the zip first (right-click > Extract All), then double-click DREADVAULT.exe
  in that folder (Windows 10/11, nothing to install). Keep the .dll next to the .exe - it
  carries the invite codes. SmartScreen "unknown publisher": More info -> Run anyway.
Linux:   chmod +x DREADVAULT.x86_64 && ./DREADVAULT.x86_64  (keep the .so files beside it)
macOS:   unzip, then right-click DREADVAULT.app -> Open (macOS 14 and older), or System
         Settings -> Privacy & Security -> Open Anyway (macOS 15). Signed, not notarized.
No download: a friend can JOIN from a browser if the host uploaded the web build
  (DREADVAULT-*-web.zip, see HOW_TO_PLAY_WITH_FRIENDS.txt "Play in the browser").

FOUND A BUG? Press F8 anywhere (or "Report a bug" in the menus). Your report is saved with
where you were and a screenshot; "Copy log" puts all of them on your clipboard. In co-op
every report also reaches the whole party.

UPDATES ARE AUTOMATIC: when a new version is out the game downloads it by itself when you
start it ("UPDATING DREADVAULT...") and restarts. Keep this folder; nothing to reinstall.

NEW IN 2.7 - KUNG POW CHICKEN. A secret gate glows dark red in the Portal Hall: stand at it, press
ENTER and speak the word. On a mountaintop dojo, Kung (panda) and Pow (gorilla) fight together -
kill them within 5 seconds of each other or the survivor goes berserk - and then Master Cluck
leaps from his throne. At low health he goes Extra Crispy and the dojo burns.

NEW IN 2.0.4: invite friends straight from the Friends list (they click Join), and Run history
at camp shows every run with its stats and build.

NEW IN 2.0.3: the vault bites back - foes and bosses hit harder, bosses are tougher, healing,
armor and rolls protect less, Ascension brings hordes. Ascension now unlocks from any guardian.
Riftbreaker: Jump Slam on Shift, and a steerable Starfall. Controller can pick relic cards.

NEW IN 2.0.1: the Riftbreaker no longer rolls - he BLOCKS (Shift/Space), healing on every hit he
stops - and has his own relics. He doesn't push bosses, but a punched foe bowls over the ones
behind it. Statues crack and crumble when foes are slammed into them. He is sealed: find the word
and type it on the hero page.

NEW IN 2.0 - THE RIFTBREAKER. A sixth hero, open to everyone: an armored brawler with a massive
relic gauntlet. Ember Shot sprays embers at close range; Relic Rush charges a huge punch that
hurls foes - into a wall, and it's a stunning WALL SLAM; Starfall leaps you up and crashes you down
where you choose. Every punch tempers your armor. Recolour the war paint in Hero & Look.

NEW IN 1.9.1: ultimates go off over anything else; TAB / SELECT shows the scoreboard mid-run;
"What's new" at camp shows every patch's buffs and nerfs; when a new build is out while you play,
an UPDATE button appears at camp. Tougher Kraken (and Sea Legs), a heavier crossbow for the Hunter,
full controller mapping, quieter Bell Foundry.

NEW IN 1.9: no more "pick a path" screens - every break is single relics, and four relics of one
path ASCEND you (four of another: twice ascended, with a second set of wings and a second halo).
The Vampire Hunter has its own relics and two new ultimates. "Abilities" on the hero page and the
scoreboard explains every move. The Warrior's Whirlwind is a real storm of blades now.

NEW IN 1.8.1: bosses are solid - nobody walks through or behind them. In a party everyone's
name and health bar float over their heads.

NEW IN 1.8 - THE VAMPIRE HUNTER. A fifth hero for whoever puts down the Warden, the Bell Colossus,
the Kraken and the Vaultlord: silver crossbow bolts, homing bats that bleed foes and drink a little
back, a Bat Swarm, a BLOOD vial for a Blood Rite, Mist instead of a roll, and Night of the Hunter.
The Deeper Vaults is now a round tower top with the Vaultlord rising on its rim - and he crumbles
to bone dust. Every guardian gets an entrance every time. Cards won by deeds come alive. The end
scoreboard has graphs: click each delver. FRIENDS at camp shows who is on, in a run, or offline.

NEW IN 1.7.3: a scoreboard and MVP at the end of every run. Updates now install a whole fresh
copy of the game by themselves (download this zip once; after that it's automatic).

NEW IN 1.7.1: press G (or middle mouse / right stick) to PING a spot for your party. Before
the Kraken you now pick 10 relics in a row. Enemies always vanish on death for everyone.

NEW IN 1.7 - THE DEEPER VAULTS. The Kraken's Tide Key opens the last gate: 15 waves (twin
Revenants, the Bell Colossus returns at 10, a final tide of 36) and then THE VAULTLORD, a
skeleton king so huge only his top half fits in the room. Strike his HANDS when they rest
after a slam and his SKULL when he bites the floor (gold edge = hit it); dodge his soul-fire
breath, his sweeping hand and, at the end, the bones falling from the dark.

NEW IN 1.6 - THE SUNKEN GALLEON. Beat the Bell Colossus and a new gate opens in the Portal
Hall: a ship in a storm, and the DROWNED KRAKEN the bells woke. Its head watches from beyond
the bow; its ARMS rise, hang over you (red line = where it lands) and slam down, tearing holes
in the deck. A slammed arm is STUCK for a few seconds with a gold edge - that is the only time
the Kraken can be hurt. At 60% the sea itself crashes over half the deck; at 30% everything.

NEW IN 1.5 - THE PORTAL HALL. "Descend" at camp leads to a hall of gates: walk into an
open gate TOGETHER to go (sealed gates tell you which key they need; the campfire in the
corner takes you back). THE FOUNDRY'S BELLS now fall - watch for the shadow - and send out
SOUND RINGS: roll through the ring or outrun it. The Bell Colossus rains bells on you and at
60% and 25% hides behind RESONANT BELLS tethered to it: split up and break them all and it
cracks open (+50% damage). New: Rally Banner and Tolling Bell (rites), Echo Strike.
Heroes glow at the edges; Settings > Glow for the soft light.

NEW IN 1.4 - THE CAMP. "Enter the vault" leads to a camp by the fire: your hero, your
calling card, two "+ Invite friend" slots, where you are going and how hard. Profile: earn
calling cards, titles and emblems from achievements, or buy cosmetic ones with souls.
Cinematics: watch scenes again. The Bell Foundry has its guardian now - the BELL COLOSSUS:
when it strikes its own bell every hammer press comes down at once, and the presses hurt it
too. Relic choice has a 30 s clock (Settings: 45 / 60 / off); the DEFAULT card is taken if
time runs out. The Hollow Warden no longer stands still. Calmer hit-stop (Settings).

THE CRYPT: survive 12 waves in the Sunken Crypt. After each wave pick 1 of 3 relics.
Every card is for YOUR class and says what it changes (attack, special, ultimate, dodge).
Relics belong to paths (Ember, Frost, Storm, Vigil, Shadow): 2 / 4 / 6 of one path awaken
blessings - and at 6 you ASCEND: horns and wings (or a crown, a halo...) for the rest of
the run, +10% damage and speed.
  RITES: some relics grant a new ability on E and R (Shadowform, Immolate, Ice Block,
         Thunderstep, Sanctuary, Rally Banner, Tolling Bell). ULTIMATE FORMS: rare relics transform your ultimate.
  Each class has its own engine: Warrior FURY, Rogue EVADE frenzy, Mage CHARGES,
  Lanternbearer SOULS (the bar under your cooldowns).
  ROGUE: alternating dagger thrusts. BACKSTAB = hit a foe from behind (+60%); AMBUSH =
  the first stab after a roll always crits; EVADE = roll through an attack (2s of crits).
  Your hero has a gold ring at its feet; the end screen says what felled you.
After waves 3, 6 and 9: the Crossroads.
  Reroll (R): new cards; the price climbs within a break and resets next break.
  Reroll one (B): pick a card - only that card is swapped for a new one (costs a reroll).
  CURSED relics (red): big power with a lasting price. Read them twice.
Waves 5 and 10: the Gravekin Revenant. "THE HORDE SURGES": a flood of foes at once.
Waves 8-11: Barrow Hounds hunt in packs and pounce along a red line - roll sideways.
Wave 12: THE HOLLOW WARDEN. Its floor cracks into lava - glowing cracks pop, then burn for a
while; more every moment the fight lasts. At 30% its burning glaives wake; at 12% a flaming
greatsword.
Seal the vault to free a secret fourth hero and unlock Ascension (harder runs).

ALONE: "Descend". Solo runs get one Lantern Ward - the first time you would fall, you rise.
HARDCORE (toggle on the front screen, or the host's toggle in the party): one life. No
Lantern Ward, no revives - whoever falls stays down. Souls x1.5, records marked HC.

WITH FRIENDS ANYWHERE (1-3 players, no router setup - see HOW_TO_PLAY_WITH_FRIENDS.txt).
  Status: internet joining is tested between game copies on one machine, not yet
  between two homes - if a code fails, use a direct code or Tailscale / Radmin VPN.
  Host:    Play with friends -> Host a party on this PC -> send the INVITE CODE (XXXX-XXXX).
  Friends: Play with friends -> type the code -> Join. Works from any home.
  Everyone presses Ready, the host presses Begin descent.
  Stand by a fallen friend for 2.5 s to raise them. Coins and souls are shared.
  Bigger parties face more, tougher foes and stronger bosses.

Controls (keyboard + mouse)
  WASD ............ move                Mouse ........... aim
  Left click ...... attack              Right click ..... special (cooldown)
  F ............... ultimate (when the ULT pip is full; it rests 6 s after use)
  Space ........... dodge roll (invulnerable while rolling; the Mage blinks)
  E / R ........... rites (abilities granted by rite relics)
  1 / 2 / 3 ....... pick a relic        R / B / S ....... reroll all / reroll one / skip
  Esc ............. pause / settings / skip a cutscene (the host skips for everyone)
Gamepad: left stick move, right stick aim, RT/X attack, Y special, LT ultimate,
  A/LB dodge, B and RB rites.

Tips: red shapes on the floor show where an attack will land - roll out before the fill
reaches the edge. Break bone gateways first. Melee swings shatter arrows and orbs.

Save data: Windows %APPDATA%\Godot\app_userdata\DREADVAULT\dreadvault_save.json
           Linux   ~/.local/share/godot/app_userdata/DREADVAULT/
           macOS   ~/Library/Application Support/Godot/app_userdata/DREADVAULT/
